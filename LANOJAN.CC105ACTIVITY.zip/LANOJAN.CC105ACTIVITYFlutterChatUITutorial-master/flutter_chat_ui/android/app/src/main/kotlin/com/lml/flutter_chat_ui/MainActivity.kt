package com.lml.flutter_chat_ui

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
